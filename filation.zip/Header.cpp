//
// Created by 18017 on 11/8/2022.
//

#include "Header.h"


vector<string> Header::getAttributes() {

    return this->attributes;
}
