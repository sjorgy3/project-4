//
// Created by 18017 on 11/8/2022.
//

#include "Tuple.h"

vector<string> Tuple::getValues() {


    return this->values;
}
