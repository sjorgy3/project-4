//
// Created by 18017 on 10/21/2022.
//

#include "Parameter.h"

string Parameter::toString() {

    return parameter;
}

Parameter::Parameter(string s) {
    parameter=s;

}
